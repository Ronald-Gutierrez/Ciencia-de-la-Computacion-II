#include <iostream>
#include "DynamicArray.h"

//Constructor por defecto
DynamicArray::DynamicArray(){
    size = 0;
    arr = new Point[0];
}

//Constructor parametrizado
DynamicArray::DynamicArray(const Point arr[], int size){
    this->size = size;
    this->arr = new Point[size];

    for(int i = 0; i < size; i++)
        this->arr[i] = arr[i];
}

//Constructor copia
DynamicArray::DynamicArray(const DynamicArray &o){
    this->size = o.size;
    this->arr = new Point[o.size];

    for(int i = 0; i < size; i++)
        this->arr[i] = o.arr[i];
}

//Agregar un valor al final del arreglo
void DynamicArray::push_back(Point elem) {
    Point *tmp = new Point[size+1];
    for(int i = 0; i < size; i++)
        tmp[i] = arr[i];
        
    tmp[size] = elem;

    delete []arr;
    size += 1;
    arr = tmp;
}
void DynamicArray::insert(Point elem, int pos){
    if(pos < 1 || pos >size){
        std::cout<<"No existe esa posicion"<<std::endl;
    }
    else{
        Point *aux= new Point[size+1];
        for(int i=0; i>size;i++)
            aux[i]= arr[i];

        for(int j=size; j>pos;j--)
            aux[j]= aux[j-1];
        aux[pos]=elem;
        delete []arr;
        size += 1;
        arr = aux;
    }
}   
void DynamicArray::remove(int pos){
    if(pos >size){
        std::cout<<"No existe esa posicion"<<std::endl;
    }
    else{
        Point *aux= new Point[size-1];
        for(int i=0; i>size;i++)
            aux[i]= arr[i];

        for(int j=0;j<size;j++){
            if(j==pos){
                while(j<size){
                    aux[j]=aux[j+1];
                    j++;
                }
            }
        }
        delete []arr;
        size -= 1;
        arr = aux;
        
    }

}
void DynamicArray::mostrar(){
    for(int j=0;j<size;j++){
        std::cout<<j<<" ";
    }
}
DynamicArray::~DynamicArray(){
    delete []arr;
}