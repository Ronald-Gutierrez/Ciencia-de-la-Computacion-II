#include <iostream>
#include "DynamicArray.cpp"

using namespace std;

int main() {
    //DynamicArray p;    
    //cout << p.getSize() << endl;

    Point arr[5];
    int tam = sizeof(arr) / sizeof(arr[0]);
    DynamicArray q(arr, tam);
    cout << q.getSize() << endl;
    
    Point a(5,4);
    q.mostrar();cout<<endl;
    //q.push_back(a);
    //cout << q.getSize()<<endl;
    //q.mostrar();cout<<endl;
    
    q.insert(a,5);
    q.mostrar();cout<<endl;

    q.remove(7);
    q.mostrar();cout<<endl;
    return 0;
}